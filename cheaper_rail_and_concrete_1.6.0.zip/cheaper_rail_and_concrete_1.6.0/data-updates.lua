data.raw["recipe"]["rail"].result_count = data.raw["recipe"]["rail"].result_count * 5
data.raw["recipe"]["concrete"].result_count = data.raw["recipe"]["concrete"].result_count * 10 